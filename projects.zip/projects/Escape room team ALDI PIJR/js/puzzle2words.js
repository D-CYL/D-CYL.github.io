let wordList = [
    {
        word: "ziekenhuis",
        hint: "waar zieke mensen gaan"
    },
    {
        word: "steam",
        hint: "bekendste video game markt"
    },
    {
        word: "rusland",
        hint: "grootste land in Europa"
    },
    {
        word: "voetbal",
        hint: "grootste sport ter wereld"
    },
    {
        word: "bitcoin",
        hint: "grootste crypto currency"
    },
    {
        word: "mcdonalds",
        hint: "Amerikaanse Fast Food company"
    },
    {
        word: "colombia",
        hint: "een land uit Zuid Amerika die begint met een C"
    },
]