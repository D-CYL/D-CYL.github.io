let wordList = [
    {
        word: "ziekenhuis",
        hint: "waar zieke mensen gaan"
    },
    {
        word: "steam",
        hint: "bekendste video game markt"
    },
    {
        word: "russland",
        hint: "grootste land in europa"
    },
    {
        word: "huis",
        hint: "waar mensen meestal wonen"
    },
    {
        word: "bitcoin",
        hint: "grootste crypto currency"
    },
    {
        word: "regen",
        hint: "water die uit lucht valt"
    },
    {
        word: "eiland",
        hint: "stuk land op water"
    },
]